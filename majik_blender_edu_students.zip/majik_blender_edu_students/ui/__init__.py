from .panel import STUDENT_PT_panel

__all__ = [
    "STUDENT_PT_panel",
]
