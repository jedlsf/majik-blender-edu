# --------------------------------------------------
# CONSTANTS
# --------------------------------------------------


SCENE_TEACHER_DOUBLE_HASH = "_tdhash"
SCENE_LOGS = "_submission_logs"
SCENE_ACTIVE_TIMER = "_student_timer"
SCENE_STUDENT_ID_HASH = "_student_id_hash"
SCENE_SIGNATURE_MODE = "_signature_mode"